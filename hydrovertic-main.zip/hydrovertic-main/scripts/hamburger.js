// Funktion til at skifte menuens synlighed
function toggleMenu() {
  console.log("Funktionen toggleMenu blev kaldt");
  const menu = document.querySelector('.menu');
  menu.classList.toggle('show-menu');
  console.log("Menuen blev vist gennem funktionen toggleMenu");
}

  // Et array af menu punkter og tilhørende URL'er
  const menuItems = [
  { text: "Dashboard", url: "dashboard.html" },
  { text: "Datalogging", url: "datalogging.html" },
  { text: "Indstillinger", url: "indstillinger.html" },
  { text: "Kontakt", url: "kontakt.html" }

];
console.log("Det virker")
// Loop gennem array for at tilføje punkter til menuen
const menuList = document.querySelector('.menu');
for (let i = 0; i < menuItems.length; i++) {
  const menuItem = document.createElement('li');
  const link = document.createElement('a');
  link.href = menuItems[i].url; // Indsæt url fra objektet
  link.textContent = menuItems[i].text;
  console.log("Link text:", menuItems[i].text);
  menuItem.appendChild(link);
  menuList.appendChild(menuItem);
}
